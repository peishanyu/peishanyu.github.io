
function loginModal() {
  var x = document.getElementById("add-modalMask");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  };

var y = document.getElementById("modal_login");
  if (y.style.display === "none") {
    y.style.display = "block";
  } else {
    y.style.display = "none";
  };	  

};

function loginModal() {
  var x = document.getElementById("add-modalMask");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  };

var y = document.getElementById("modal_login");
  if (y.style.display === "none") {
    y.style.display = "block";
  } else {
    y.style.display = "none";
  };	  

};




function changeToLogin(){
	var userLoginShow=document.getElementById("userLogin");
	userLogin.style.display="block";
	var userSignupHide=document.getElementById("userSignup");
	userSignup.style.display="none";
}

function changeToSignUp(){
	var userLoginHide=document.getElementById("userLogin");
	userLogin.style.display="none";
	var userSignupShow=document.getElementById("userSignup");
	userSignup.style.display="block";
}

